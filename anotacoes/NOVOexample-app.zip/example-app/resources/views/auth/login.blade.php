@extends('layouts.gpt')

@section('header', 'Fazer Login')

@section('content')

    <table border = "1">
        <tr> 
            <td>Nome</td>
            
        </tr>
        <tr>
            <td>Fulano</td>
           
        </tr>
    //Fazer formulário de login


@endsection