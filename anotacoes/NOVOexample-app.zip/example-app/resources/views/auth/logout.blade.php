@extends('layouts.gpt')

@section('header', 'Fazer Logout')

@section('content')

    <h1>Asta la vista</h1>
   


@endsection