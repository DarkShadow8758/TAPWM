@extends('layouts.gpt')

@section('header', 'Listar todos os usuários')

@section('content')

    <table border = "1">
        <tr> 
            <td>Nome</td>
            <td>Email</td>
        </tr>
        <tr>
            <td>Fulano</td>
            <td>fulano@gmail.com</td>
        </tr>



@endsection