@extends('layouts.gpt')

@section('header', 'Deletar o usuário')

@section('content')

<h1>Hello WOrld!</h1>
   

@endsection