@extends('layouts.gpt')

@section('header', 'Listar os usuários pelo ID')

@section('content')

    <table border = "1">
        <tr>
            <td>ID</td>
            <td>Nome</td>
        </tr>
        <tr>
            <td>061123</td>
            <td>Fulano</td>
        </tr>



@endsection 