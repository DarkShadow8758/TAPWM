

<?php $__env->startSection('header', 'Listar todos os usuários'); ?>

<?php $__env->startSection('content'); ?>

    <table border = "1">
        <tr>
            <td>Nome</td>
            <td>Email</td>
        </tr>
        <tr>
            <td>Fulano</td>
            <td>fulano@gmail.com</td>
        </tr>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.gpt', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\0031432412026\Downloads\example-app\resources\views/users/listAllUsers.blade.php ENDPATH**/ ?>