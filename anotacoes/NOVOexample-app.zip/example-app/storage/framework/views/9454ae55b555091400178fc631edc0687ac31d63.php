

<?php $__env->startSection('header', 'Listar os usuários pelo ID'); ?>

<?php $__env->startSection('content'); ?>

    <table border = "1">
        <tr>
            <td>Nome</td>
            <td>ID</td>
        </tr>
        <tr>
            <td>Fulano</td>
            <td>061123</td>
        </tr>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.gpt', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\0031432412026\Downloads\example-app\resources\views/users/listUsersByID.blade.php ENDPATH**/ ?>