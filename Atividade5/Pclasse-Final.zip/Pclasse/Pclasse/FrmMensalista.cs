﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pclasse
{
    public partial class FrmMensalista : Form
    {
        public FrmMensalista()
        {
            InitializeComponent();
        }

        private void btnInstancias1_Click(object sender, EventArgs e)
        {
            Mensalista objMensalista = new Mensalista();

            objMensalista.NomeEmpregado = txtNome.Text;
            objMensalista.Matricula = Convert.ToInt32(txtMatricula.Text);
            objMensalista.DataEntradaEmpresa = Convert.ToDateTime(txtData.Text);
            objMensalista.SalarioMensal = Convert.ToDouble(txtSalario.Text);

            MessageBox.Show("Nome = " + objMensalista.NomeEmpregado + "\n" +
                "Matrícula = " + objMensalista.Matricula + "\n" +
                "Tempo Trabalho = " + objMensalista.TempoTrabalho() + "\n" +
                "Salário Final = " + objMensalista.SalarioBruto().ToString("N2"));

            //static
            MessageBox.Show(Mensalista.Empresa);
            MessageBox.Show(Mensalista.Filial); 

        }

        private void btnInstancia2_Click(object sender, EventArgs e)
        {
            Mensalista ObjMensalista = new Mensalista(
                Convert.ToInt32(txtMatricula.Text),
                txtNome.Text,
                Convert.ToDateTime(txtData.Text),
                Convert.ToDouble(txtSalario.Text));

            MessageBox.Show("Nome: " + ObjMensalista.NomeEmpregado + "\n" +
                "Matrícula: " + ObjMensalista.Matricula + "\n" +
                "Tempo Trabalho: " + ObjMensalista.TempoTrabalho() + "\n" +
                "Salário Final: " + ObjMensalista.SalarioBruto().ToString("N2"));
        }
    }
}
