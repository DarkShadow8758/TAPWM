var texto = "Observe que eessa mensagem vem do módulo";
module.exports = texto;